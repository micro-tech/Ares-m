## 2.3.1-pre.1

Added iOS and Android > 3.0 narrow screen detection with fallback to original detection method
for deciding if panels should have the narrow layout.
