enyo.depends(
	'HTMLStringDelegate.js'
);