enyo.depends(
	'DocumentFragmentDelegate.js'
);