enyo.depends(
	"views.js"
);
